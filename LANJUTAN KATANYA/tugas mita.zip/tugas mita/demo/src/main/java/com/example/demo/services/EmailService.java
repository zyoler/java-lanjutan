package com.example.demo.services;

import com.example.demo.dto.MallRequest;
import com.example.demo.dto.MallResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.internet.MimeMessage;

@Service
public class EmailService {
    @Autowired
    private JavaMailSender sender;

    @Autowired
    public EmailService(JavaMailSender mailSender){
        this.sender = mailSender;
    }

    public MallResponse sendEmail(MallRequest request){
        MallResponse response = new MallResponse();
        MimeMessage message = sender.createMimeMessage();

        try{
            MimeMessageHelper helper = new MimeMessageHelper(message);

            helper.setTo(request.getTo());
            helper.setSubject("Biodata");
            helper.setFrom("mitairuz1210@gmail.com");
            helper.setText("<table style=\"text-align: left;\">" +
                    "        <tr>" +
                    "            <th>Nama</th>" +
                    "            <td>:</td>" +
                    "            <td>" + request.getNama() + "</td>" +
                    "        </tr>" +
                    "        <tr>" +
                    "            <th>Nim</th>" +
                    "            <td>:</td>" +
                    "            <td>" + request.getNim() + "</td>" +
                    "        </tr>" +
                    "        <tr>" +
                    "            <th>Jenis kelamin</th>" +
                    "            <td>:</td>" +
                    "            <td>" + request.getJk() + "</td>" +
                    "        </tr>" +
                    "    </table>", true);

            sender.send(message);

            response.setPesan("Email terkirim ke : " + request.getTo());
            response.setStatus(Boolean.TRUE);

        }catch (Exception e){
            e.printStackTrace();
            response.setPesan("Email gagal dikirim ke : " + request.getTo());
            response.setStatus(Boolean.FALSE);
        }
        return response;
    }
}
