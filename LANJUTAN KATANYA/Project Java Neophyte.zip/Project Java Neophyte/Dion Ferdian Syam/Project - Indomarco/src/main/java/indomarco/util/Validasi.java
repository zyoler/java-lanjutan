package indomarco.util;

public class Validasi {
    public static boolean empty(String string){
        return string.trim().isEmpty();
    }
}
