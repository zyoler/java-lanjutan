package indomarco.objects;

public class UserLogin {

}
