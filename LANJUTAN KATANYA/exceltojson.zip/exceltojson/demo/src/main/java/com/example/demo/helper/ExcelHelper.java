package com.example.demo.helper;

import com.example.demo.models.Mahasiswa;
import org.apache.poi.ss.usermodel.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ExcelHelper {
    public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    public static boolean hasExcelFormat(MultipartFile file) {
        if(!TYPE.equals(file.getContentType())){
            return false;
        }
        return true;
    }

    public static List<Mahasiswa> excelToMahasiswa(InputStream is) {
        try {
            Workbook workbook = WorkbookFactory.create(is);
            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rows = sheet.iterator();
            ArrayList<Mahasiswa> mhs = new ArrayList<Mahasiswa>();
            int rowNumber = 0;
            while(rows.hasNext()) {
                Row currentRow = rows.next();
                //Untuk skip header
                if (rowNumber == 0){
                    rowNumber++;
                    continue;
                }
                Iterator<Cell> cellsInRow = currentRow.iterator();
                Mahasiswa mahasiswa = new Mahasiswa();
                int cellIdx = 0;
                while(cellsInRow.hasNext()) {
                    Cell currentCell = cellsInRow.next();
                    switch (cellIdx) {
                        case 0:
                            mahasiswa.setNim(currentCell.getStringCellValue());
                            break;
                        case 1:
                            mahasiswa.setNama(currentCell.getStringCellValue());
                            break;
                        case 2:
                            mahasiswa.setAlamat(currentCell.getStringCellValue());
                            break;
                        default:
                            break;
                    }
                    cellIdx++;
                }
                mhs.add(mahasiswa);
            }
            workbook.close();
            return mhs;
        } catch (IOException e) {
            throw new RuntimeException("Fail to parse Excel file: " + e.getMessage());
        }
    }
}
