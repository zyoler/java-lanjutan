package com.example.demo.dto;

public class MahasiswaDto {
    private Integer id;
    private String nim, nama, alamat;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

//    public String getJk() {
//        return jk;
//    }
//
//    public void setJk(String jk) {
//        this.jk = jk;
//    }
//
//    public String getJurusan() {
//        return jurusan;
//    }
//
//    public void setJurusan(String jurusan) {
//        this.jurusan = jurusan;
//    }
//
//    public String getNohp() {
//        return nohp;
//    }
//
//    public void setNohp(String nohp) {
//        this.nohp = nohp;
//    }
//
//    public String getEmail() {
//        return email;
//    }
//
//    public void setEmail(String email) {
//        this.email = email;
//    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }
}
