package com.example.demo.dto;

public class SearchDto {
    String cari;

    public String getCari() {
        return cari;
    }

    public void setCari(String cari) {
        this.cari = cari;
    }
}
