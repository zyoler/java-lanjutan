package org.pubpasim.mudik;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MudikUmatApplicationTests {

	@Test
	void contextLoads() {
	}

}
