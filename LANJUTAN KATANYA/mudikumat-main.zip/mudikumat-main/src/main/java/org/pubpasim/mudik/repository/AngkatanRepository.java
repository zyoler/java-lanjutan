package org.pubpasim.mudik.repository;

import org.pubpasim.mudik.model.Angkatan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AngkatanRepository extends JpaRepository<Angkatan, String> {}