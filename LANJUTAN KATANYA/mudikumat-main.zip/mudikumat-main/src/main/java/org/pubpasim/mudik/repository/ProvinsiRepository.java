package org.pubpasim.mudik.repository;

import org.pubpasim.mudik.model.Provinsi;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProvinsiRepository extends JpaRepository<Provinsi, Integer> {}