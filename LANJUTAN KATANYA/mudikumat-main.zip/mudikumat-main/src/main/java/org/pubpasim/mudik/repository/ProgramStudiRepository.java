package org.pubpasim.mudik.repository;

import org.pubpasim.mudik.model.ProgramStudi;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProgramStudiRepository extends JpaRepository<ProgramStudi, String> {}