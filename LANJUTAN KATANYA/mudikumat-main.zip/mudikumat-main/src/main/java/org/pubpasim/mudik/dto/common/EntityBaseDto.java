package org.pubpasim.mudik.dto.common;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EntityBaseDto {

    private String deskripsi;

}