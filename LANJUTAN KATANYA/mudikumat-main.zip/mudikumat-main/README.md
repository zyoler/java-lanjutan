# Selamat datang di MudikUmat!
Sistem informasi mudik resmi Pemberdayaan Umat Berkelanjutan.

## Kata sandi default
Kata sandi semua akun sebelum diubah:

1234

## Login sebagai bukan admin
Login dengan nama pengguna berikut:

* ilfa
* sandi
* romi

## Login sebagai admin
Login dengan nama pengguna berikut:

* junkssiboga
* aderadia
* randi

## Fitur utama

* Mudah digunakan
* Diamankan dengan teknologi Spring Security, kata sandi Anda sama sekali tidak disimpan di dalam basis data
* Memiliki API yang mencakup sebagian besar data
* Open source, dilisensikan di bawah Lisensi MIT

## Fitur UI

* Menerapkan pedoman desain material yang terinspirasi oleh Google Material Design
* Mendukung tema gelap
* Responsif
* Ringan, karena dibuat tanpa CSS library (Bulma, Bootstrap, dll.)