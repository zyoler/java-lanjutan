package com.example.demo.controller;

import com.example.demo.dto.AdminDto;
import com.example.demo.models.AdminModels;
import com.example.demo.repositories.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpSession;
import java.util.Objects;

@Controller
public class LoginController {
    @Autowired
    AdminRepository adminRepository;

    AdminDto adminDto = new AdminDto();

    @RequestMapping("/login")
    public String login(Model model){
        model.addAttribute("adminDto", adminDto);
        return "login";
    }

    @RequestMapping(value = "/cekLogin", method = RequestMethod.POST)
    public String cekLogin(AdminDto adminDto, HttpSession session) {

        AdminModels admin = adminRepository.getAdminByEmail(adminDto.getEmail());
        if(Objects.equals(adminDto.getEmail(), "admin@gmail.com")){
            if(adminDto.getEmail().equalsIgnoreCase(admin.getEmail()) && adminDto.getPassword().equalsIgnoreCase(admin.getPassword())) {
                session.setAttribute("email", admin.getEmail());
                return "redirect:/dashboard";
            }else{
                return "redirect:/login";
            }
        }else{
            return "redirect:/login";
        }
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String logout(HttpSession httpSession){
        httpSession.removeAttribute("email");
        return "redirect:/login";
    }
}
